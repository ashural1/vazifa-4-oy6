import PhoneNumberForm from "./input";
import "./Number.css";
function App() {
  return <PhoneNumberForm />;
}
export default App;
